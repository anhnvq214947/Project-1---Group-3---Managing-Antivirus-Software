# Project-1---Group-3---Managing-Antivirus-Software
This is a project for subject Project 1 at Hanoi University of Science and Technology by Nguyen Viet Quy Anh and Hoang Son Tung 
# Topic Detail
Build a program to manage a ClamAV antivirus software on Linux
# Student information
Nguyễn Viết Quý Anh : 20214947
email : anh.nvq214947@sis.hust.edu.vn 
Hoàng Sơn Tung :
email :
## API

## GUI app design 

# Folder Structure 

